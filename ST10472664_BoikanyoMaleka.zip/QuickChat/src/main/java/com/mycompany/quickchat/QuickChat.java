/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchat;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


/**
 *
 * @author RC_Student_lab
 */
public class QuickChat {

    private static final ArrayList<String> sentMessages = new ArrayList<>();
    private static int totalMessagesSent = 0;
    private static final String JSON_FILE = "stored_messages.json";
    private static String currentUserFirstName;
    private static String currentUserLastName;

    public static void main(String[] args) {
        // Registration
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        String phoneNumber = JOptionPane.showInputDialog("Enter South African phone number:");
        currentUserFirstName = JOptionPane.showInputDialog("Enter your first name:");
        currentUserLastName = JOptionPane.showInputDialog("Enter your last name:");

        // Validate registration input
        validateInput(username, password, phoneNumber);

        // Login
        if (performLogin(username, password)) {
            showMenu();
        }
    }

    public static void validateInput(String username, String password, String phoneNumber) {
        if (isValidUsername(username)) {
            JOptionPane.showMessageDialog(null, "Username successfully captured.");
        } else {
            JOptionPane.showMessageDialog(null, "Username must contain an underscore and be 5 characters or less.");
        }

        if (isValidPassword(password)) {
            JOptionPane.showMessageDialog(null, "Password successfully captured.");
        } else {
            JOptionPane.showMessageDialog(null, "Password must be at least 8 characters, include uppercase, lowercase, a number, and a special character.");
        }

        if (isValidPhoneNumber(phoneNumber)) {
            JOptionPane.showMessageDialog(null, "Phone number successfully captured.");
        } else {
            JOptionPane.showMessageDialog(null, "Phone number must start with +27 or 0 and have correct length.");
        }
    }

    public static boolean performLogin(String username, String password) {
        String inputUsername = JOptionPane.showInputDialog("Enter username to login:");
        String inputPassword = JOptionPane.showInputDialog("Enter password to login:");

        if (isValidUsername(username) && isValidPassword(password) &&
                username.equals(inputUsername) && password.equals(inputPassword)) {
            JOptionPane.showMessageDialog(null, "Welcome " + currentUserFirstName + " " + currentUserLastName + ", good to see you!");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Invalid credentials. Try again.");
            return false;
        }
    }

    // ========== VALIDATION UTILITY METHODS ==========

    public static boolean isValidUsername(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    public static boolean isValidPassword(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasUpper = password.matches(".*[A-Z].*");
        boolean hasLower = password.matches(".*[a-z].*");
        boolean hasDigit = password.matches(".*\\d.*");
        boolean hasSpecial = password.matches(".*[!@#$%^&*()_+=\\-{}\\[\\]:;\"'<>,.?/].*");
        return hasUpper && hasLower && hasDigit && hasSpecial;
    }

    public static boolean isValidPhoneNumber(String phone) {
        return phone != null && (
            (phone.startsWith("+27") && phone.length() == 12) ||
            (phone.startsWith("0") && phone.length() == 11)
        );
    }

    public static String checkMessageLength(String message) {
        if (message == null) message = "";
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = message.length() - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
    }

    // ========== MENU & ACTIONS ==========

    private static void showMenu() {
        boolean running = true;
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");

        while (running) {
            String menuOptions = """
                === QuickChat Menu ===
                1) Send Message
                2) Show Recently Sent Messages
                3) View Message Statistics
                4) View Stored Messages
                5) Quit""";

            String choiceStr = JOptionPane.showInputDialog(menuOptions);
            if (choiceStr == null) break;

            try {
                int choice = Integer.parseInt(choiceStr);
                switch (choice) {
                    case 1 -> sendMessage();
                    case 2 -> showRecentMessages();
                    case 3 -> showMessageStatistics();
                    case 4 -> showStoredMessages();
                    case 5 -> {
                        JOptionPane.showMessageDialog(null, "Total messages sent: " + totalMessagesSent + "\nGoodbye!");
                        running = false;
                    }
                    default -> JOptionPane.showMessageDialog(null, "Invalid selection. Try again.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Enter a valid number.");
            }
        }
    }

    // This is the zero-argument sendMessage() used by the menu
    private static void sendMessage() {
        // You can implement this to prompt user for recipient and message and then call sendMessage(String, String)
        String recipient = JOptionPane.showInputDialog("Enter recipient phone number:");
        String messageContent = JOptionPane.showInputDialog("Enter message content:");
        if (recipient == null || messageContent == null) {
            JOptionPane.showMessageDialog(null, "Cancelled.");
            return;
        }
        String result = sendMessage(recipient, messageContent);
        JOptionPane.showMessageDialog(null, result);
    }

    // This is the public method your tests and external classes can call
    public static String sendMessage(String recipient, String messageContent) {
        if (!isValidPhoneNumber(recipient)) {
            return "Invalid phone number.";
        }
        String lengthCheck = checkMessageLength(messageContent);
        if (!lengthCheck.equals("Message ready to send.")) {
            return lengthCheck;
        }
        String messageId = generateMessageId();
        int currentIndex = totalMessagesSent + 1;
        String messageHash = generateMessageHash(recipient, currentIndex, messageContent);

        JSONObject messageObj = new JSONObject();
        messageObj.put("MessageID", messageId);
        messageObj.put("Recipient", recipient);
        messageObj.put("Message", messageContent);
        messageObj.put("MessageHash", messageHash);
        messageObj.put("Sender", currentUserFirstName + " " + currentUserLastName);

        sendMessageNow(messageObj);
        return "Message sent.";
    }

    public static String generateMessageHash(String phone, int index, String message) {
        String prefix = phone.substring(0, 2);
        String[] words = message.trim().split("\\s+");
        String first = words[0].replaceAll("\\W", "");
        String last = words[words.length - 1].replaceAll("\\W", "");
        return String.format("%s:%d:%s%s", prefix, index, first.toUpperCase(), last.toUpperCase());
    }

    public static String generateMessageId() {
        long min = 1000000000L;
        long max = 9999999999L;
        long randomNum = min + (long) (Math.random() * (max - min + 1));
        return String.valueOf(randomNum);
    }

    public static String sendMessageAction(String action) {
        return switch (action.toLowerCase()) {
            case "send" -> "Message successfully sent.";
            case "store" -> "Message successfully stored.";
            case "discard", "disregard" -> "Press 0 to delete message.";
            default -> "Unknown action.";
        };
    }

    private static void sendMessageNow(JSONObject message) {
        totalMessagesSent++;
        sentMessages.add("To: " + message.get("Recipient") + " | ID: " + message.get("MessageID") + " | Hash: " + message.get("MessageHash"));

        String info = """
            Message Sent!
            ID: %s
            Hash: %s
            To: %s
            Content: %s
            From: %s""".formatted(
                message.get("MessageID"),
                message.get("MessageHash"),
                message.get("Recipient"),
                message.get("Message"),
                message.get("Sender"));

        JOptionPane.showMessageDialog(null, info);
    }

    private static void storeMessage(JSONObject message) {
        JSONArray messages = loadStoredMessages();
        messages.add(message);
        try (FileWriter writer = new FileWriter(JSON_FILE)) {
            writer.write(messages.toJSONString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving message: " + e.getMessage());
        }
    }

    private static JSONArray loadStoredMessages() {
        File file = new File(JSON_FILE);
        if (!file.exists()) return new JSONArray();

        try (FileReader reader = new FileReader(file)) {
            return (JSONArray) new JSONParser().parse(reader);
        } catch (IOException | ParseException e) {
            return new JSONArray();
        }
    }

    private static void showRecentMessages() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent yet.");
            return;
        }

        StringBuilder sb = new StringBuilder("=== Recently Sent Messages ===\n");
        for (String msg : sentMessages) {
            sb.append(msg).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void showMessageStatistics() {
        String lastMsgId = sentMessages.isEmpty() ? "N/A" : sentMessages.get(sentMessages.size() - 1).split("\\|")[1].trim();
        JOptionPane.showMessageDialog(null,
            "=== Message Stats ===\n" +
            "Total messages sent: " + totalMessagesSent + "\n" +
            "Last message ID: " + lastMsgId);
    }

    private static void showStoredMessages() {
        JSONArray messages = loadStoredMessages();
        if (messages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No stored messages found.");
            return;
        }

        StringBuilder sb = new StringBuilder("=== Stored Messages ===\n");
        for (Object obj : messages) {
            JSONObject msg = (JSONObject) obj;
            sb.append("ID: ").append(msg.get("MessageID"))
              .append(" | To: ").append(msg.get("Recipient"))
              .append(" | Hash: ").append(msg.get("MessageHash"))
              .append("\nContent: ").append(msg.get("Message")).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }
}
