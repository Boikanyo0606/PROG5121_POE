/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.quickchat;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class QuickChatTest {
    
    public QuickChatTest() {
    }

    @Test
    public void testIsValidUsername() {
        assertTrue(QuickChat.isValidUsername("abc_"));
        assertTrue(QuickChat.isValidUsername("a_bcd"));
        assertFalse(QuickChat.isValidUsername("abcdef"));
        assertFalse(QuickChat.isValidUsername("abc"));
    }

    @Test
    public void testIsValidPassword() {
        assertTrue(QuickChat.isValidPassword("Strong1!"));
        assertFalse(QuickChat.isValidPassword("weak"));
        assertFalse(QuickChat.isValidPassword("NoSpecial1"));
        assertFalse(QuickChat.isValidPassword("nocaps1!"));
        assertFalse(QuickChat.isValidPassword("NoNumber!"));
    }

    @Test
    public void testIsValidPhoneNumber() {
        assertTrue(QuickChat.isValidPhoneNumber("+27718693002"));
        assertTrue(QuickChat.isValidPhoneNumber("08575975889"));
        assertFalse(QuickChat.isValidPhoneNumber("+1234567890"));
        assertFalse(QuickChat.isValidPhoneNumber("083123456"));
        assertFalse(QuickChat.isValidPhoneNumber("1234567890"));
    }

    @Test
    public void testCheckMessageLength() {
        String validMsg = "Hello".repeat(40); // 200 chars
        String longMsg = "A".repeat(251);
        assertEquals("Message ready to send.", QuickChat.checkMessageLength(validMsg));
        assertEquals("Message exceeds 250 characters by 1, please reduce size.",
                QuickChat.checkMessageLength(longMsg));
    }

    @Test
    public void testGenerateMessageHash() {
        assertEquals("27:0:HITONIGHT",
                QuickChat.generateMessageHash("+27718693002", 0, "Hi Mike, can you join us for dinner tonight"));
        assertEquals("08:1:HIPAYMENT",
                QuickChat.generateMessageHash("08575975889", 1, "Hi Keegan, did you receive the payment?"));
    }

    @Test
    public void testGenerateMessageId() {
        String messageId = QuickChat.generateMessageId();
        assertEquals(10, messageId.length());
        assertTrue(messageId.matches("\\d{10}"));
    }

    @Test
public void testSendMessage() {
    String testPhone = "+27718693002";

    assertEquals("Message successfully sent.", QuickChat.sendMessage(testPhone, "Send"));
    assertEquals("Press 0 to delete message.", QuickChat.sendMessage(testPhone, "Disregard"));
    assertEquals("Message successfully stored.", QuickChat.sendMessage(testPhone, "Store"));
}

    }

