/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatfinal;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
/**
 *
 * @author RC_Student_lab
 */
public class QuickChatFinal {


    private static final ArrayList<String> sentMessages = new ArrayList<>();
    private static final ArrayList<String> disregardedMessages = new ArrayList<>();
    private static final ArrayList<String> messageHashes = new ArrayList<>();
    private static final ArrayList<String> messageIDs = new ArrayList<>();
    private static int totalMessagesSent = 0;
    private static final String JSON_FILE = "stored_messages.json";
    private static String currentUserFirstName;
    private static String currentUserLastName;

    public static void main(String[] args) {
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        String phoneNumber = JOptionPane.showInputDialog("Enter South African phone number:");
        currentUserFirstName = JOptionPane.showInputDialog("Enter your first name:");
        currentUserLastName = JOptionPane.showInputDialog("Enter your last name:");

        validateInput(username, password, phoneNumber);

        if (performLogin(username, password)) {
            showMenu();
        }
    }

    public static void validateInput(String username, String password, String phoneNumber) {
        if (isValidUsername(username)) {
            JOptionPane.showMessageDialog(null, "Username successfully captured.");
        } else {
            JOptionPane.showMessageDialog(null, "Username must contain an underscore and be 5 characters or less.");
        }

        if (isValidPassword(password)) {
            JOptionPane.showMessageDialog(null, "Password successfully captured.");
        } else {
            JOptionPane.showMessageDialog(null, "Password must be at least 8 characters, include uppercase, lowercase, a number, and a special character.");
        }

        if (isValidPhoneNumber(phoneNumber)) {
            JOptionPane.showMessageDialog(null, "Phone number successfully captured.");
        } else {
            JOptionPane.showMessageDialog(null, "Phone number must start with +27 or 0 and have correct length.");
        }
    }

    public static boolean performLogin(String username, String password) {
        String inputUsername = JOptionPane.showInputDialog("Enter username to login:");
        String inputPassword = JOptionPane.showInputDialog("Enter password to login:");

        if (isValidUsername(username) && isValidPassword(password) &&
                username.equals(inputUsername) && password.equals(inputPassword)) {
            JOptionPane.showMessageDialog(null, "Welcome " + currentUserFirstName + " " + currentUserLastName + ", good to see you!");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Invalid credentials. Try again.");
            return false;
        }
    }

    public static boolean isValidUsername(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    public static boolean isValidPassword(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasUpper = password.matches(".*[A-Z].*");
        boolean hasLower = password.matches(".*[a-z].*");
        boolean hasDigit = password.matches(".*\\d.*");
        boolean hasSpecial = password.matches(".*[!@#$%^&*()_+=\\-{}\\[\\]:;\"'<>,.?/].*");
        return hasUpper && hasLower && hasDigit && hasSpecial;
    }

    public static boolean isValidPhoneNumber(String phone) {
        return phone != null && (
            (phone.startsWith("+27") && phone.length() == 12) ||
            (phone.startsWith("0") && phone.length() == 11)
        );
    }

    public static String checkMessageLength(String message) {
        if (message == null) message = "";
        return message.length() <= 250 ? "Message ready to send." : "Message exceeds 250 characters by " + (message.length() - 250);
    }

    private static void showMenu() {
        boolean running = true;

        while (running) {
            String choiceStr = JOptionPane.showInputDialog("""
                === QuickChat Menu ===
                1) Send Message
                2) Show Recently Sent Messages
                3) View Message Statistics
                4) View Stored Messages
                5) Show Senders & Recipients
                6) Show Longest Message
                7) Search by Message ID
                8) Search by Recipient
                9) Delete by Message Hash
                10) Show Full Message Report
                11) Quit""");

            if (choiceStr == null) break;
            try {
                int choice = Integer.parseInt(choiceStr);
                switch (choice) {
                    case 1 -> sendMessage();
                    case 2 -> showRecentMessages();
                    case 3 -> showMessageStatistics();
                    case 4 -> showStoredMessages();
                    case 5 -> showSendersAndRecipients();
                    case 6 -> showLongestMessage();
                    case 7 -> searchByMessageID();
                    case 8 -> searchByRecipient();
                    case 9 -> deleteByMessageHash();
                    case 10 -> showMessageReport();
                    case 11 -> {
                        JOptionPane.showMessageDialog(null, "Total messages sent: " + totalMessagesSent + "\nGoodbye!");
                        running = false;
                    }
                    default -> JOptionPane.showMessageDialog(null, "Invalid selection. Try again.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Enter a valid number.");
            }
        }
    }

    private static void sendMessage() {
        String recipient = JOptionPane.showInputDialog("Enter recipient phone number:");
        String messageContent = JOptionPane.showInputDialog("Enter message content:");
        if (recipient == null || messageContent == null) {
            JOptionPane.showMessageDialog(null, "Cancelled.");
            return;
        }
        String result = sendMessage(recipient, messageContent);
        JOptionPane.showMessageDialog(null, result);
    }

    public static String sendMessage(String recipient, String messageContent) {
        if (!isValidPhoneNumber(recipient)) return "Invalid phone number.";
        String lengthCheck = checkMessageLength(messageContent);
        if (!lengthCheck.equals("Message ready to send.")) return lengthCheck;

        String messageId = generateMessageId();
        String messageHash = generateMessageHash(recipient, totalMessagesSent + 1, messageContent);

        messageHashes.add(messageHash);
        messageIDs.add(messageId);

        JSONObject messageObj = new JSONObject();
        messageObj.put("MessageID", messageId);
        messageObj.put("Recipient", recipient);
        messageObj.put("Message", messageContent);
        messageObj.put("MessageHash", messageHash);
        messageObj.put("Sender", currentUserFirstName + " " + currentUserLastName);

        sendMessageNow(messageObj);
        storeMessage(messageObj);
        return "Message sent.";
    }

    public static String generateMessageHash(String phone, int index, String message) {
        String prefix = phone.substring(0, 2);
        String[] words = message.trim().split("\\s+");
        String first = words[0].replaceAll("\\W", "");
        String last = words[words.length - 1].replaceAll("\\W", "");
        return String.format("%s:%d:%s%s", prefix, index, first.toUpperCase(), last.toUpperCase());
    }

    public static String generateMessageId() {
        return String.valueOf(1000000000L + (long) (Math.random() * 8999999999L));
    }

    private static void sendMessageNow(JSONObject message) {
        totalMessagesSent++;
        sentMessages.add("To: " + message.get("Recipient") + " | ID: " + message.get("MessageID") + " | Hash: " + message.get("MessageHash"));
    }

    private static void storeMessage(JSONObject message) {
        JSONArray messages = loadStoredMessages();
        messages.add(message);
        try (FileWriter writer = new FileWriter(JSON_FILE)) {
            writer.write(messages.toJSONString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving message: " + e.getMessage());
        }
    }

    private static JSONArray loadStoredMessages() {
        File file = new File(JSON_FILE);
        if (!file.exists()) return new JSONArray();
        try (FileReader reader = new FileReader(file)) {
            return (JSONArray) new JSONParser().parse(reader);
        } catch (IOException | ParseException e) {
            return new JSONArray();
        }
    }

    private static void showRecentMessages() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent yet.");
            return;
        }
        StringBuilder sb = new StringBuilder("=== Recently Sent Messages ===\n");
        sentMessages.forEach(msg -> sb.append(msg).append("\n"));
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void showMessageStatistics() {
        String lastMsgId = sentMessages.isEmpty() ? "N/A" : sentMessages.get(sentMessages.size() - 1).split("\\|")[1].trim();
        JOptionPane.showMessageDialog(null, "=== Message Stats ===\nTotal messages sent: " + totalMessagesSent + "\nLast message ID: " + lastMsgId);
    }

    private static void showStoredMessages() {
        JSONArray messages = loadStoredMessages();
        if (messages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No stored messages found.");
            return;
        }
        StringBuilder sb = new StringBuilder("=== Stored Messages ===\n");
        for (Object obj : messages) {
            JSONObject msg = (JSONObject) obj;
            sb.append("ID: ").append(msg.get("MessageID"))
              .append(" | To: ").append(msg.get("Recipient"))
              .append(" | Hash: ").append(msg.get("MessageHash"))
              .append("\nContent: ").append(msg.get("Message")).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void showSendersAndRecipients() {
        JSONArray messages = loadStoredMessages();
        StringBuilder sb = new StringBuilder("=== Senders and Recipients ===\n");
        for (Object obj : messages) {
            JSONObject msg = (JSONObject) obj;
            sb.append("Sender: ").append(msg.get("Sender"))
              .append(" | Recipient: ").append(msg.get("Recipient"))
              .append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void showLongestMessage() {
        JSONArray messages = loadStoredMessages();
        String longest = "";
        for (Object obj : messages) {
            JSONObject msg = (JSONObject) obj;
            String content = (String) msg.get("Message");
            if (content.length() > longest.length()) longest = content;
        }
        JOptionPane.showMessageDialog(null, "Longest Message:\n" + longest);
    }

    private static void searchByMessageID() {
        String id = JOptionPane.showInputDialog("Enter message ID to search:");
        JSONArray messages = loadStoredMessages();
        for (Object obj : messages) {
            JSONObject msg = (JSONObject) obj;
            if (msg.get("MessageID").equals(id)) {
                JOptionPane.showMessageDialog(null, "Found:\nTo: " + msg.get("Recipient") + "\nMessage: " + msg.get("Message"));
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "No message found with that ID.");
    }

    private static void searchByRecipient() {
        String number = JOptionPane.showInputDialog("Enter recipient number:");
        JSONArray messages = loadStoredMessages();
        StringBuilder sb = new StringBuilder();
        for (Object obj : messages) {
            JSONObject msg = (JSONObject) obj;
            if (msg.get("Recipient").equals(number)) {
                sb.append("ID: ").append(msg.get("MessageID"))
                  .append(" | Message: ").append(msg.get("Message"))
                  .append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, sb.length() > 0 ? sb.toString() : "No messages found.");
    }

    private static void deleteByMessageHash() {
        String hash = JOptionPane.showInputDialog("Enter message hash to delete:");
        JSONArray messages = loadStoredMessages();
        JSONArray updated = new JSONArray();
        boolean found = false;
        for (Object obj : messages) {
            JSONObject msg = (JSONObject) obj;
            if (!msg.get("MessageHash").equals(hash)) {
                updated.add(msg);
            } else {
                disregardedMessages.add((String) msg.get("Message"));
                found = true;
            }
        }
        if (found) {
            try (FileWriter writer = new FileWriter(JSON_FILE)) {
                writer.write(updated.toJSONString());
                JOptionPane.showMessageDialog(null, "Message deleted.");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(null, "Hash not found.");
        }
    }

    private static void showMessageReport() {
        JSONArray messages = loadStoredMessages();
        StringBuilder sb = new StringBuilder("=== Full Message Report ===\n");
        for (Object obj : messages) {
            JSONObject msg = (JSONObject) obj;
            sb.append("ID: ").append(msg.get("MessageID"))
              .append(" | To: ").append(msg.get("Recipient"))
              .append(" | Hash: ").append(msg.get("MessageHash"))
              .append("\nMessage: ").append(msg.get("Message"))
              .append("\nFrom: ").append(msg.get("Sender"))
              .append("\n\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }
}

    

