/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.quickchatfinal;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import javax.swing.JOptionPane;
import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author RC_Student_lab
 */
public class QuickChatFinalTest {
    /* reflection handles */
    private static Field sentFld, hashFld, idFld, totalFld,
                         firstNameFld, lastNameFld;
    private static Method loadStoredMeth, deleteByHashMeth;

    /* ───────────── one‑time setup ───────────── */
    @BeforeAll
    static void reflect() throws Exception {
        sentFld        = QuickChatFinal.class.getDeclaredField("sentMessages");
        hashFld        = QuickChatFinal.class.getDeclaredField("messageHashes");
        idFld          = QuickChatFinal.class.getDeclaredField("messageIDs");
        totalFld       = QuickChatFinal.class.getDeclaredField("totalMessagesSent");
        firstNameFld   = QuickChatFinal.class.getDeclaredField("currentUserFirstName");
        lastNameFld    = QuickChatFinal.class.getDeclaredField("currentUserLastName");
        loadStoredMeth = QuickChatFinal.class.getDeclaredMethod("loadStoredMessages");
        deleteByHashMeth = QuickChatFinal.class.getDeclaredMethod("deleteByMessageHash");

        for (Field f : List.of(sentFld, hashFld, idFld, totalFld,
                               firstNameFld, lastNameFld)) f.setAccessible(true);
        loadStoredMeth.setAccessible(true);
        deleteByHashMeth.setAccessible(true);
    }

    /* helper to load the stored JSON list */
    @SuppressWarnings("unchecked")
    private static JSONArray stored() throws Exception {
        return (JSONArray) loadStoredMeth.invoke(null);
    }

    /* reset static state + seed messages */
    @BeforeEach
    void resetAndSeed() throws Exception {
        new File("stored_messages.json").delete();

        ((List<?>) sentFld.get(null)).clear();
        ((List<?>) hashFld.get(null)).clear();
        ((List<?>) idFld.get(null)).clear();
        totalFld.setInt(null, 0);
        firstNameFld.set(null, "Unit");
        lastNameFld.set(null, "Tester");

        QuickChatFinal.sendMessage("+27838884567", "Did you get the cake?");
        QuickChatFinal.sendMessage("+27838884567", "Where are you? You are late! I have asked you to be on time.");
        QuickChatFinal.sendMessage("+27838884567", "Ok, I am leaving without you.");
        QuickChatFinal.sendMessage("+27838884567", "It is dinner time!");
    }

    /* ───────────── tests ───────────── */

    @Test
    void sentMessagesArrayPopulated() throws Exception {
        @SuppressWarnings("unchecked")
        List<String> sent = new ArrayList<>((List<String>) sentFld.get(null));

        Assertions.assertAll(
            () -> Assertions.assertEquals(4, sent.size()),
            () -> Assertions.assertTrue(sent.get(0).contains("Did you get the cake?")),
            () -> Assertions.assertTrue(sent.get(3).contains("It is dinner time!"))
        );
    }

    @Test
    void longestMessage() throws Exception {
        String longest = "";
        for (Object o : stored()) {
            String msg = (String) ((JSONObject) o).get("Message");
            if (msg.length() > longest.length()) longest = msg;
        }
        Assertions.assertEquals(
            "Where are you? You are late! I have asked you to be on time.",
            longest);
    }

    @Test
    void searchByMessageID() throws Exception {
        @SuppressWarnings("unchecked")
        String id = ((List<String>) idFld.get(null)).get(3);       // 4th msg
        boolean found = false;
        for (Object o : stored()) {
            JSONObject j = (JSONObject) o;
            if (id.equals(j.get("MessageID"))
                && "It is dinner time!".equals(j.get("Message"))) {
                found = true;
                break;
            }
        }
        Assertions.assertTrue(found);
    }

    @Test
    void searchAllByRecipient() throws Exception {
        List<String> msgs = new ArrayList<>();
        for (Object o : stored()) {
            JSONObject j = (JSONObject) o;
            if ("+27838884567".equals(j.get("Recipient"))) {
                msgs.add((String) j.get("Message"));
            }
        }

        Assertions.assertAll(
            () -> Assertions.assertEquals(4, msgs.size()),
            () -> Assertions.assertTrue(msgs.contains(
                 "Where are you? You are late! I have asked you to be on time.")),
            () -> Assertions.assertTrue(msgs.contains("Ok, I am leaving without you."))
        );
    }

    @Test
    void deleteByHash() throws Exception {
        @SuppressWarnings("unchecked")
        String hash = ((List<String>) hashFld.get(null)).get(1);   // second msg

        try (MockedStatic<JOptionPane> pane = Mockito.mockStatic(JOptionPane.class)) {
            pane.when(() -> JOptionPane.showInputDialog(Mockito.anyString()))
                .thenReturn(hash);
            pane.when(() -> JOptionPane.showMessageDialog(Mockito.any(), Mockito.anyString()))
                .thenAnswer(inv -> null);

            deleteByHashMeth.invoke(null);                         // run deletion
        }

        boolean stillThere = false;
        for (Object o : stored()) {
            if (hash.equals(((JSONObject) o).get("MessageHash"))) {
                stillThere = true;
                break;
            }
        }
        Assertions.assertFalse(stillThere, "Message should be deleted");
    }

    @Test
    void reportFieldsPresent() throws Exception {
        StringBuilder rep = new StringBuilder();
        for (Object o : stored()) {
            JSONObject j = (JSONObject) o;
            rep.append(j.get("MessageHash"))
               .append(j.get("Recipient"))
               .append(j.get("Message"));
        }
        String r = rep.toString();
        Assertions.assertAll(
            () -> Assertions.assertTrue(r.contains("Did you get the cake?")),
            () -> Assertions.assertTrue(r.contains("+27838884567")),
            () -> Assertions.assertTrue(r.contains("Message"))   // field name present
        );
    }
}
